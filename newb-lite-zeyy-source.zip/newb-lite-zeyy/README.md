# Newb X Legacy

**Newb X Legacy** is a RenderDragon successor to the legacy GLSL shader, [Newb Shader](https://github.com/devendrn/newb-shader-mcbe). It is an enhanced vanilla shader that focuses on being lightweight and having soft aesthetics. It supports Minecraft Bedrock 1.26+ (Windows/Android/iOS).

<br>

![Screenshots](docs/screenshots.jpg "Newb X Legacy 15.47, MCBE 1.21.0")

## Downloads

You can download the shader pack from [release page](https://github.com/devendrn/newb-x-mcbe/releases/latest).

## Installation

> [!NOTE]
> Shaders are not officially supported on Minecraft Bedrock. The following are unofficial ways to load shaders. There are multiple ways to get it working. Start with the recommended method. If that doesn't work try the other method.

### Android

| **Using MB Loader App** |
|:-|
| 1. Install [MB Loader App](https://play.google.com/store/apps/details?id=io.github.bambosan.mbloader) |
| 2. Launch Minecraft from MB Loader. |
| 2. Import the resource pack and activate it in global resources. |

### Windows

| **Using Wyvern Loader** |
|:-|
| 1. Download and setup Wyvern from [here](https://github.com/mcbegamerxx954/wyvern_releases/releases/latest) |
| 2. Open Minecraft then click 'Inject' in Wyvern |
| 3. Import the resource pack and activate it in global resources. |

### Linux / Mac
This method is for [mcpelauncher-manifest](https://minecraft-linux.github.io/).

| **Using MaterialBinLoader mod (Recommended): x86_64 arch** |
|:-|
| 1. Install [mcpelauncher-materialbinloader-mod](https://github.com/CrackedMatter/mcpelauncher-materialbinloader/releases/latest). |
| 2. Import the resource pack and activate it in global resources. |

| **Using shaders mod: x86_64, x86, arm64, arm arch** |
|:-|
| 1. Download [mcpelauncher-shadersmod](https://github.com/GameParrot/mcpelauncher-shadersmod/releases/latest). |
| 2. Follow this [guide](https://faizul726.github.io/guides/shadersmodinstallation) to setup. |


### iOS
Using shaders on iOS is not very straightforward and not recommended for beginners.

| **Using Minecraft with Hynis** |
|:-|
| 1. Download Minecraft with Hynis IPA file from our [Discord server](https://discord.com/invite/newb-community-844591537430069279). |
| 2. Sideload it with your preferred sideloading tool. |
| 3. Import the resource pack and activate it in global resources. |

<br>

## Building

### Install dependencies
- [Git](https://git-scm.com/)
- [Python](https://www.python.org/) 3.11 or higher required
- Python packages:
  - [lazurite](https://veka0.github.io/lazurite/#installation) (Must be `v0.12.0`. Newer or older version may not be supported)
  - [rich](https://rich.readthedocs.io/en/stable/introduction.html#installation) (Must be `v14+`)

### Get source code
```
git clone https://github.com/devendrn/newb-x-mcbe/ -c core.symlinks=true
cd newb-x-mcbe
```

### Install dependencies from requirements.txt
*Skip if you already have installed those versions.*
```
python -m pip install -r requirements.txt
```

### Setup build environment
> [!NOTE]
> On Windows, run `.\build.bat` instead of `./build.sh` for all following commands.
```
./build.sh setup
```
This will download shaderc binary and material data required to build shader.

<br>

### Compile specific shader materials
```
./build.sh mats
```
Compiled material.bin files will be inside `build/<platform>/`

**Command usage:**
```
usage: build mats [-h] [-p {android,windows,ios,multiplatform}] [-m M [M ...]] [-s S]

options:
  -h, --help            show this help message and exit
  -p {android,windows,multiplatform,ios}
                        build profile
  -m M [M ...]          build materials (eg: Sky)
  -s S                  subpack config to use (eg: NO_WAVE)
```

### Compile and build full shader pack
```
./build.sh pack
```

The final mcpack will be inside `build/`.

**Command usage:**
```
usage: build pack [-h] [-p {android,windows,ios,multiplatform}] [--no-zip] [--no-label] [-v V]

options:
  -h, --help            show this help message and exit
  -p {android,windows,multiplatform,ios}
                        build profile
  --no-zip              don't make archive
  --no-label            don't label materials
  -v V                  version number eg: 17
```

> [!TIP]
> If you want to customize pack name, author, version and other details, you can do so in `src/newb/pack_config.toml`.

<br>

## Development

Clangd can be used to get code completion and error checks for source files inside include/newb. Fake bgfx header and clangd config are provided for the same.
- **Neovim**: Install clangd LSP.
- **VSCode**: Install [vscode-clangd](https://marketplace.visualstudio.com/items?itemName=llvm-vs-code-extensions.vscode-clangd) extension.

## License

**Source Code:** The "Newb Shader" source code is licensed under the MIT License. You are free to modify, distribute, and create derivative works based on the source code.

**Compiled Resource Packs (`.mcpack` files):** The compiled resource packs distributed by the "Newb Shader" project and its variant creators are copyrighted works with restrictions. See the `COPYRIGHT.txt` file within each resource pack for more information.

---
## Newb X Legacy Lite By Zeyy (build via GitHub Actions)
Source ini dibuat dari `Newb_Lite_By_Zeyy.mcpack` dengan sky upstream tanpa glow matahari + material SunMoon (lihat `src/newb/config.h`:
`NL_SUN_*`, `NL_SKY_MOON_GLOW`). Build: Actions -> **build-newb-lite** -> Run workflow -> platform `android`.
Hasil: artifact `Newb_Lite_By_Zeyy-android` berisi `Newb_Lite_By_Zeyy-android.mcpack`.
