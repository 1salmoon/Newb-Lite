#ifndef INSTANCING
  $input a_color0, a_position
  $output v_worldPos, v_underwaterRainTimeDay, v_sunDirDay
#endif

#include <bgfx_shader.sh>

#ifndef INSTANCING
  #include <newb/main.sh>

  //uniform vec4 SkyColor;
  uniform vec4 FogColor;
  uniform vec4 FogAndDistanceControl;
  uniform vec4 ViewPositionAndTime;
  uniform vec4 TimeOfDay;
#endif

void main() {
  #ifndef INSTANCING
    v_underwaterRainTimeDay.x = float(detectUnderwater(FogColor.rgb, FogAndDistanceControl.xy));
    v_underwaterRainTimeDay.y = detectRain(FogAndDistanceControl.xyz);
    v_underwaterRainTimeDay.z = ViewPositionAndTime.w;
    v_underwaterRainTimeDay.w = detectDayFactor(FogColor.rgb);

    // arah matahari + dayFactor dihitung sekali per vertex (bukan per pixel)
    nl_environment sunEnv;
    sunEnv = calculateSunParams(sunEnv, TimeOfDay.x);
    v_sunDirDay = vec4(sunEnv.sunDir, sunEnv.dayFactor);

    // background quad
    vec4 pos = vec4(a_position.xzy, 1.0);
    pos.xy = 2.0*clamp(pos.xy, -0.5, 0.5);

    //v_fogColor = FogColor.rgb;
    v_worldPos = mul(u_invViewProj, pos).xyz;

    gl_Position = pos;
  #else
    gl_Position = vec4(0.0, 0.0, 0.0, 0.0);
  #endif
}
